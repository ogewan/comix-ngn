<?php function writer_settings(){?>
<script>
    var pageD = <?php $screen = get_current_screen();$pID =substr(strrchr($screen->id,"_"),1);echo $pID;?>;
    var defer = !0;/*,
        mainsrc = <?php echo '"'+plugins_url( '/js/comixngn.min.js', __FILE__ )+'"';?>,
        loadng = ["http://comixngn.js.org/ghs/1.1.1/plugins/comixngn.jq.js","http://code.jquery.com/jquery-2.1.4.min.js", "https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"],
        aftjq = ["http://code.jquery.com/ui/1.11.4/jquery-ui.min.js", "https://cdnjs.cloudflare.com/ajax/libs/spectrum/1.7.0/spectrum.min.js"],
        fuse = {fstrun: false, pgepsh: false, pgesve: false, rtepge: false, protect: false, noverwrite: false, arrow: true, addme: false, embed: true},
        plugin = "",
        disable = ["rollbar"],
        comicID="CNGwriter",
        dir = "",
        tir = "",
        $GPC = $GPC + 1 || 1;
        /*cG={agent:function(e,t){return t=new XMLHttpRequest,t.open("GET",e),e=[],t.onreadystatechange=t.then=function(n,s,a){if(n&&n.call&&(e=[,n,s]),4==t.readyState&&(a=e[0|t.status/200]))try{a(JSON.parse(t.responseText),t)}catch(c){a(t.responseText,t)}},t.send(),t},REPO:{scReq:{address: "http://comixngn.js.org/"}},dis:{}};*/
</script>
<style>.glyphicon,.icon{cursor:pointer}#nav-toolbar li{list-style-type:none;display:inline}.tile{margin-left:10px;margin-top:10px}.modify{-webkit-box-shadow:0 0 10px 10px rgba(72,53,212,1);-moz-box-shadow:0 0 10px 10px rgba(72,53,212,1);box-shadow:0 0 10px 10px rgba(72,53,212,1)}
</style>
<script type="text/javascript" src="http://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/spectrum/1.7.0/spectrum.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/spectrum/1.6.1/spectrum.min.css">
<link rel="stylesheet" type="text/css" href="https://bootswatch.com/simplex/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/humane-js/3.2.2/themes/flatty.min.css" />
<div class="wrap">
<h2 id="$COMICNGWRITER$$$">Writer</h2>
<div id="accordion">
    <h3 class="button" role="button">* Settings</h3>
    <div id="settings_contain">
        <form method="post" action="options.php">
            <?php settings_fields( 'my-cool-plugin-settings-group' ); ?>
            <?php do_settings_sections( 'my-cool-plugin-settings-group' ); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">New Option Name</th>
                    <td>
                        <input type="text" name="new_option_name" value="<?php echo esc_attr( get_option('new_option_name') ); ?>" />
                    </td>
                </tr>

                <tr valign="top">
                    <th scope="row">Some Other Option</th>
                    <td>
                        <input type="text" name="some_other_option" value="<?php echo esc_attr( get_option('some_other_option') ); ?>" />
                    </td>
                </tr>

                <tr valign="top">
                    <th scope="row">Options, Etc.</th>
                    <td>
                        <input type="text" name="option_etc" value="<?php echo esc_attr( get_option('option_etc') ); ?>" />
                    </td>
                </tr>
            </table>
            <table id="bodtab" border="0" style="width:100%">
                <tr>
                    <td colspan="2">
                        <h4 id="confhead" title="Click to toggle border">Configuration</h4>
                    </td>
                </tr>
                <tr>
                    <td title="Image directory">
                        <label for="dir">Directory</label>
                        <input value="assets/" id="dir" type="text">
                    </td>
                    <td title="Select this if you want to continue from a previous configuration.">
                        <label for="historian">Config File</label>
                        <input id="historian" type="file" accept=".json" style="display: inline;">
                    </td>
                </tr>
                <tr>
                    <td>
                        <label for="psn_0">Page Start</label>
                        <input type="radio" id="psn_0" name="psb" checked>0&nbsp;
                        <input type="radio" id="psn_1" name="psb">1</td>
                    <td>
                        <label for="csn_0">Chapter Start</label>
                        <input type="radio" id="csn_0" name="csb" checked>0&nbsp;
                        <input type="radio" id="csn_1" name="csb">1</td>
                </tr>
                <tr>
                    <td title="How far behind images are preloaded">
                        <label for="prb">Pre-Buffer</label>
                        <input type="number" value=5 id="prb" min="1" max="100">
                    </td>
                    <td title="How far ahead images are preloaded">
                        <label for="ptb">Post-Buffer</label>
                        <input type="number" value=5 id="ptb" min="1" max="100">
                    </td>
                </tr>
                <?php if($pID != '-1')
                echo '<tr>
                    <td title="An additive json is a file that allows pages to be added by url alone">
                        <label for="add_">Additive pages</label>
                        <input value="" id="add_" type="text">
                        <!--<input type="radio" id="add_0" name="aad" checked>Disabled&nbsp;
                <input type="radio" id="add_1" name="aad">Enabled</td>-->
                        <td title="Merge these additive into pages of the script">
                            <label for="mergeadd">Additive Merge</label>
                            <input id="mergeadd" type="file" accept=".json" style="display: inline;">
                        </td>
                </tr>';
                ?>
                <tr>
                    <td style="vertical-align:top" title="If there are more images in the directory than in +the configuration file, attempt to automatically add them">
                        <label for="pyr_0">Append on Page Mismatch</label>
                        <input type="radio" id="pyr_0" name="pyrt" checked>On&nbsp;
                        <input type="radio" id="pyr_1" name="pyrt">Off</td>
                    <td rowspan="2" style="vertical-align:top" title="The order in which the images should be appended">
                        <label for="spyr_0">Append Order</label>
                        <input type="radio" id="spyr_0" name="spyrt" checked>Modified&nbsp;
                        <input type="radio" id="spyr_1" name="spyrt">Name&nbsp;
                        <input type="radio" id="spyr_2" name="spyrt">Size&nbsp;
                        <input type="radio" id="spyr_3" name="spyrt">Type&nbsp;
                        <br>
                        <input type="radio" id="spyro_0" name="spyrto" checked>Descending&nbsp;
                        <input type="radio" id="spyro_1" name="spyrto">Ascending</td>
                </tr>
                <tr>
                    <td title="The page that the comic loads first, either start from the beginning or the most recent">
                        <label for="strp">Start Page</label>
                        <input type="number" id="strp" name="strp" min="0" value=0>
                    </td>
                </tr>
                <tr>
                    <td title="Background color of webcomic">
                        <label for="back_total">Background: </label>
                        <input id="back_color" style="visibility: hidden;">
                    </td>
                    <td title="Order of navigation button: Left to Right or Right to Left">
                        <label for="rdr_0">Reading Direction</label>
                        <input type="radio" id="rdr_0" name="rdi" checked>L -> R&nbsp;
                        <input type="radio" id="rdr_1" name="rdi">R -> L</td>
                </tr>
                <tr>
                    <td colspan="8">
                        <div class="spoiler" data-spoiler-link="1">
                            <button>Loading Spinner</button>
                        </div>
                        <div class="spoiler-content" data-spoiler-link="1">
                            <table>
                                <tr>
                                    <td>
                                        <label for="dia">Diameter</label>
                                        <input style="width:100px;" type="number" value=250 id="dia" min="1">
                                    </td>
                                    <td rowspan="8">
                                        <canvas id="custom_spin" class="center"></canvas>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label for="wid">Lines: </label>
                                        <input style="width:35px;" type="number" value=16 id="lin" min="1">
                                        <label for="rat">Rate(ms): </label>
                                        <input style="width:65px;" step="any" value=33.333333333333336 id="rat" min="1">
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label for="xpose">X-pos</label>
                                        <input style="width:50px;" type="number" step="0.01" value=0.5 id="xpose" min="0" max="1">
                                        <label for="ypose">Y-pos</label>
                                        <input style="width:50px;" type="number" step="0.01" value=0.5 id="ypose" min="0" max="1">
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label for="back_load">Background: </label>
                                        <input id="back_load">
                                        <label for="color_load">Color: </label>
                                        <input id="color_load">
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </td>
                </tr>
                <?php if($pID != '-1')
                echo '<tr>
                    <!--FilePaneToolbar-->
                    <td colspan=2 style="border: 4px solid #E2E2E2;background-color:#E2E2E2;width:100%;padding:5px">
                        <button id="AChp">Add Chapter</button>
                        &nbsp;&nbsp;&nbsp;&nbsp;
                        <button id="APge">Add Page</button>
                        &nbsp;&nbsp;&nbsp;&nbsp;
                        <button id="TpDir">Top Directory</button>
                        &nbsp;&nbsp;&nbsp;&nbsp;
                        <button id="UpDir">Up Directory</button>
                        &nbsp;&nbsp;&nbsp;&nbsp;
                        <label for='."Multi".'>Select Multiple&nbsp;</label>
                        <input id='."Multi".' type='."checkbox".'> &nbsp;&nbsp;&nbsp;&nbsp;
                        <input style="display: inline" id="conductor" type="file" multiple>
                        <input type="radio" id="fm_0" name="fm" checked>Page&nbsp;
                        <input type="radio" id="fm_1" name="fm">Chapter</td>
                    </td>
                </tr>
                <tr>
                    <!--FilePane-->
                    <td style="border: 4px solid #E2E2E2;width=20%;vertical-align:top">
                        <!--FilePaneTree-->
                        <!--glyphicon glyphicon-folder-open
                glyphicon glyphicon-file-->
                        <ul id="Tsort" class="empty">
                        </ul>
                    </td>
                    <td style="border: 4px solid #E2E2E2;width=80%;vertical-align:top">
                        <!--FilePaneGrid/List-->
                        <span id="edit"></span>
                        <ul id="Dsort" class="empty">
                        </ul>
                    </td>
                </tr>' ?>
            </table>
            <input id="ExBtn" type="submit" value="Export" title="Save Settings">

            <!--<a href="../../" style="position:fixed;width:42px;height:42px;top:20px;left:10px;"><img src="../../assets/images/normal_glow.svg" style="position:absolute;top:0;left:0;width:90%;"/></a>-->
            <span id=MHEAD></span>
            <div id="nav-toolbar" style="border: 2px groove; position: fixed; left: 50%; z-index: 9;">
                <ul style="padding: 0px; margin: 0px; top: 50%;">
                    <li>
                        <button id="nav-move"><span class="glyphicon glyphicon-move" aria-hidden="true" style="z-index:999;"></span>
                        </button>
                    </li>
                    <!--<li><button id="nav-undo"><span class="glyphicon glyphicon-arrow-left" aria-hidden="true" style="z-index:999;"></span></button></li>
            <li><button id="nav-redo"><span class="glyphicon glyphicon-arrow-right" aria-hidden="true" style="z-index:999;"></span></button></li>-->
                    <li>
                        <!--<select id="nav-select" data-mini="true" data-inline="true">
                    <option value="list">List</option>
                    <option value="thum">Thumbnail</option>
                </select>-->
                    </li>
                    <li>
                        <button id="_set">* Settings</button>
                    </li>
                    <li>
                        <button id="ExBtnCL" title="Save Settings">Export</button>
                    </li>
                    <li><span id=MHEADCL></span>
                    </li>
                    <li>
                        <button id="_des">* Design</button>
                    </li>
                </ul>
            </div>
<script>
    var setup = function(){
        render();
    };
    var rootCHP = [];
    var explorer = function(map,pg,cp){
        var tree = '',
            TFoT = '<li><span class="glyphicon glyphicon-folder-open">',
            TFiT = '<li><span class="glyphicon glyphicon-file">',
            TClo = '</span></li>';
        for (var name in map) {
            if (map.hasOwnProperty(name)) {
                if(name=='-1'){
                    continue;
                } else{
                    //print chapter
                    //console.log(name);
                    tree += TFoT+" "+cp[name].title+" | pages: "+cp[name].start+" - "+cp[name].end+"<ul>"+explorer(map[name])+"</ul>"+TClo;
                }
            }
        }
        var namP;
        for(var page in map[-1]){
            if(pg[page].url.length>0){
                namP = pg[page].url[0].split("/");
                namP = namP[namP.length-1];
                namP = namP.split(".")[0];
            } else
                namP='';
            tree += TFiT+" "+namP+" | urls: "+pg[page].url.length+TClo;
        }
        return tree;
    }
    var render= function(attempts) {
        if (attempts === void 0 || attempts === null) attempts = 0;
        else if (attempts>20){
            console.error("render has timed out");
            return;
        }
        if(cG.comix===void 0){
            if(cG.stageInjection===void 0){
                setTimeout(render, 200,++attempts);
                return;
            }
            cG.script = {parent:null,offset:0,pyr:{appendmismatch:false,appendorder:0,appendorderdir:false},loading:{diameter: 250,lines:16,rate:33.333333333333336,xpos:0.5,ypos:0.5,back:"#FFF",color:"#373737"},config:{dir:"assets/",pagestartnum:false,chapterstartnum:false,imgprebuffer:5,imgpostbuffer:5,startpage:0,back:"#FFF"},pages:[],chapters:[]};
            cG.stageInjection();
        }
        var p = cG.comix.internals.pages;
        var c = cG.comix.internals.chapters;
        if (p.length+c.length < 1) {
            $("#Tsort").removeClass("empty");
            $("#Dsort").removeClass("empty");
        } else{
            $("#Tsort").addClass("empty");
            $("#Dsort").addClass("empty");
        }
        //console.log(p);
        //console.log(c);
        var tree = '',
            grid = '',
            DFoT = "<img class='icon tile' style='width:72px;height:72px;' src='"+ficon+"'",
            DFiT = "<img class='icon tile' style='width:72px;height:72px;' src='",
            DClo = "'>",
            chhr = {'-1':[]},
            wido,
            queue = [],
            namP;
        queue[p.length-1]=1;
        queue.fill(1, 0, p.length);
        for(var a=0;a<c.length;a++){//iterate through chapters
            if(c[a].parent<0){
                wido = chhr[a] = {'-1':[]};
            } else {
                //console.log(a,c[a].parent);
                if(c[a].parent==a||c[c[a].parent].parent==a){//sanity check
                    //I am my parent
                    if(c[a].parent==a) console.error("Rendering Error: Parent is Self");
                    //I am the parent of my parent 
                    if(c[c[a].parent].parent==a) console.error("Rendering Error: Parent is a Child");
                    return;
                }
                wido = chhr[c[a].parent][a] = {'-1':[]};
            }
            if(c[a].start>=0&&c[a].end>=0){
                for(var b=0;b<=(c[a].end-c[a].start);b++){
                    if(queue[c[a].start+b]){
                        wido[-1].push(c[a].start+b);
                        queue[c[a].start+b]=0;
                    }
                }
            }
        }
        if(p.length!=queue.length) console.log("MISMATCH",p.length,queue.length,queue);
        for(var d=0;d<p.length;d++){
            if(!queue[d]) continue;
            chhr[-1].push(d);
        }
        //console.log(chhr);
        if(!rootCHP.length){//top level
            for (var name in chhr) {
                if (chhr.hasOwnProperty(name)) {
                    if(name=='-1'){
                        continue;
                    } else{
                        if(c[name].thumb==""||c[name].thumb===void 0){
                            if((editfile.id==name)&&editfile.type)
                                grid += "<img class='icon tile modify' style='width:72px;height:72px;' src='folder_icon.png'";
                            else
                                grid += DFoT;
                        }
                        else{
                            if((editfile.id==name)&&editfile.type)
                                grid += "<img class='icon tile modify' style='width:72px;height:72px;' src='"+cG.comix.internals.config.dir+c[name].thumb+"'";
                            else
                                grid += DFiT+cG.comix.internals.config.dir+c[name].thumb+"'";
                        }
                        grid += "id='c"+name+"' onclick='settings(c" + name + ")'>";
                    }
                }
            }
            for(var page in chhr[-1]){
                if((editfile.id==page)&&!editfile.type)
                    grid += "<img class='icon tile modify' style='width:72px;height:72px;' src='";
                else
                    grid += DFiT;
                if (!p[page].absolute) grid += cG.comix.internals.config.dir;
                grid += p[page].url[0]+"'id='s"+page+"' onclick='settings(s" + page + ")'>";
            }
        } else{
            var ship=chhr;
            for(var path in rootCHP)
                ship=ship[path];
            for (var name in ship) {
                if (ship.hasOwnProperty(name)) {
                    if(name=='-1'){
                        continue;
                    } else{
                        if(c[name].thumb==""||c[name].thumb===void 0){
                            if((editfile.id==name)&&editfile.type)
                                grid += "<img class='icon tile modify' style='width:72px;height:72px;' src='folder_icon.png'";
                            else
                                grid += DFoT;
                        }
                        else{
                            if((editfile.id==name)&&editfile.type)
                                grid += "<img class='icon tile modify' style='width:72px;height:72px;' src='"+cG.comix.internals.config.dir+c[name].thumb+"'";
                            else
                                grid += DFiT+cG.comix.internals.config.dir+c[name].thumb+"'";
                        }
                        grid += "id='c"+name+"' onclick='settings(c" + name + ")'>";
                    }
                }
            }
            for(var page in ship[-1]){
                if((editfile.id==page)&&!editfile.type)
                    grid = "<img class='icon tile modify' style='width:72px;height:72px;' src='";
                return
                    grid += DFiT
                if (!p[page].absolute) grid += cG.comix.internals.config.dir;
                grid += p[page].url[0]+"'id='s"+page+"' onclick='settings(s" + page + ")'>";
            }
        }
        tree=explorer(chhr,p,c);
        //console.log(tree);
        $("#Tsort").html(tree);
        $("#Dsort").html(grid);
    };
    var editfile = {id: [-1], type: 0, dirty: false, multi: false},
        //id corresponds with index in page/chapter array, type is 0 = page or 1 = chapter, dirty is whether or not changes need to be saved
        expfunct,
        settings,
        remveC,
        remveP,
        report,
        workhorse = function() {
            if (settings,void 0 === window.jQuery || void 0 === window.jQuery.ui || void 0 === humane||void 0 === cG.comix)
                return setTimeout(workhorse, 300);
            /*var jQ = jQuery.noConflict();*/
            console.log("%c %c %c comix-ngn Writer v" + cG.info.vwr + " %c \u262F %c \u00A9 2015 Oluwaseun Ogedengbe %c ", "color:white; background:#B5B5B5", "background:purple", "color:black; background:#E2E2E2", 'color:red; background:black', "color:black; background:#B5B5B5", "background:purple");
            var Virtual = cG.comix.internals;
            //Loading Spinner GFX INIT
            var spin = {
                start: Date.now(),
                lines: 16,
                rate: 33.333333333333336,
                cwidth: 300,
                cheight: 150,
                diameter: 250,
                xpos: 0.5,
                ypos: 0.5,
                back: "#fff",
                color: "#373737",
                context: document.getElementById("custom_spin").getContext("2d")
            },
                fspin = function() {
                    $("#custom_spin").css("background",spin.back);
                    var rotation = Math.floor(((Date.now() - spin.start) / 1000) * spin.lines) / spin.lines,
                        c = spin.color.substr(1);
                    spin.context.save();
                    spin.context.clearRect(0, 0, spin.cwidth, spin.cheight);
                    spin.context.translate(spin.cwidth / 2, spin.cheight / 2);
                    spin.context.rotate(Math.PI * 2 * rotation);
                    if (c.length == 3) c = c[0] + C[0] + c[1] + c[1] + c[2] + c[2];
                    var red = parseInt(c.substr(0, 2), 16).toString(),
                        green = parseInt(c.substr(2, 2), 16).toString(),
                        blue = parseInt(c.substr(4, 2), 16).toString();
                    for (var i = 0; i < spin.lines; i++) {
                        spin.context.beginPath();
                        spin.context.rotate(Math.PI * 2 / spin.lines);
                        spin.context.moveTo(spin.diameter / 10, 0);
                        spin.context.lineTo(spin.diameter / 4, 0);
                        spin.context.lineWidth = spin.diameter / 30;
                        spin.context.strokeStyle = "rgba(" + red + "," + green + "," + blue + "," + i / spin.lines + ")";
                        spin.context.stroke();
                    }
                    spin.context.restore();
                    /*console.log(spin.rate)*/
                    window.setTimeout(fspin, spin.rate);
                }
            //
            //$("#CHPHEAD").data({});
            //Writer GUI Options
            $("#confhead").click(function() {
                if ($("#bodtab").attr("border") == "1") {
                    $("#bodtab").attr("border", "0");
                } else {
                    $("#bodtab").attr("border", "1");
                }
            });
            $("#accordion").accordion({
                collapsible: true,
                heightStyle: "content"
            });
            /*.sortable({
                        axis: "y",
                        handle: "h3",
                        stop: function( event, ui ) {
                          // IE doesn't register the blur when sorting
                          // so trigger focusout handlers to remove .ui-state-focus
                          ui.item.children( "h3" ).triggerHandler( "focusout" );

                          // Refresh accordion to handle new order
                          $( this ).accordion( "refresh" );
                        }
                      });*/
            //Loader spinner GFX color settings
            $.data($("#back_color"),"color","#fff");
            $("#back_color").spectrum({
                color: "#fff",
                change: function(color) {
                    $.data($("#back_color"),"color",color.toHexString());
                }
            }).css("visibility", "visible" );
            $("#color_load").spectrum({
                color: "#373737",
                change: function(color){
                    spin.color = color.toHexString();
                }
            });
            $("#back_load").spectrum({
                color: "#fff",
                change: function(color){
                    spin.back = color.toHexString(); 
                }
            });
            $(".spoiler").spoiler();
            window.setTimeout(fspin, spin.rate);
            var spinsetchange = function(){
                spin.lines = $("#lin").val();
                spin.rate = jaz.resolveRPN(jaz.shuntingYard($("#rat").val()));
                $("#rat").val(spin.rate);
                spin.diameter = $("#dia").val();
                spin.xpos = $("#xpose").val();
                spin.ypos = $("#ypose").val();
            }
            $("#lin").change(spinsetchange);
            $("#rat").change(spinsetchange);
            $("#dia").change(spinsetchange);
            $("#xpose").change(spinsetchange);
            $("#ypose").change(spinsetchange);
            $("#back_load").change(spinsetchange);
            $("#color_load").change(spinsetchange);
            /*
        $(".spoiler-content").show();
        $("#design_contain").show();*/
            var addthing = function(page, source) {
                if(source===void 0)
                    source = {image: ''};
                if(page)
                    Virtual.pages.push({alt:"",hover:"",title:"",url:[source.image],release:0,note:"",perm:!1,anim8:!1, absolute:false});
                else
                    Virtual.chapters.push({description:"",end: -1,start: -1,title: "Chapter",thumb: source.image, parent:-1});
                render();
            }
            $("#AChp").click(function() {
                addthing(false);
            });
            $("#APge").click(function() {
                addthing(true);
            });
            $("#TpDir").click(function() {
                rootCHP = [];
            });
            $("#UpDir").click(function() {
                rootCHP.pop();
            });
            $("#Multi").change(function() {
                editfile.multi = document.getElementById('Multi').checked;
            });
            $("#conductor").change(function() {
                if ($("#sorted").hasClass("empty")) {
                    $("#sorted").removeClass("empty");
                }
                console.log(this.files);
                for (var i = 0; i < this.files.length; i++) {
                    addthing(document.getElementById('fm_0').checked,{image:this.files[i].name});
                }
            });
            $("#mergeadd").change(function() {
                delete window.confirm;
                if ((!$("#Tsort").hasClass("empty") || !$("#Dsort").hasClass("empty")) && !confirm("This will add pages, are you sure?")) {
                    this.files = {};
                    return;
                }
                //console.log(this.files);
                if (!this.files.length) return;
                
                $("#sorted").empty();
                $("#Csort").empty();
                /*if (!this.files[0].type.match()) {
                    throw "File Type must be an image";
                }*/

                // Using FileReader to display the image content
                var reader = new FileReader();
                reader.onload = function(e) {
                    var result = JSON.parse(e.target.result);
                    if(result.p===void 0||result.p===null) return -1;
                    if(!result.p.length) return -1;
                    /*if(!cG.script.pages[0].url.length){
                        //removes empty pages before add render
                        cG.REPO.script.def.pages.splice(0, 1);
                        cG.script = cG.REPO.script.def;
                    }*/
                    cG.script = cG.REPO.script.def = result;
                    report(cG.script);
                    $(".venue").stageInjection();
                    Virtual = cG.comix.internals;
                };
                reader.readAsText(this.files[0]);
            });
            $("#historian").change(function() {
                //delete window.confirm;
                if ((!$("#Tsort").hasClass("empty") || !$("#Dsort").hasClass("empty")) && !confirm("This will overwrite your current configuration, are you sure?")) {
                    this.files = {};
                    return;
                }
                console.log(this.files);
                if (!this.files.length) return;
                /*$("#sorted").innerHTML ="";*/
                //console.log("INSIDE",$("#sorted"),$("#sorted").html());
                $("#Dsort").empty();
                $("#Tsort").empty();

                /*if (!this.files[0].type.match()) {
                    throw "File Type must be an image";
                }*/

                // Using FileReader to display the image content
                var reader = new FileReader();
                reader.onload = function(e) {
                    var result = JSON.parse(e.target.result);
                    if(result.config===void 0||result.config===null)
                        return -1;
                    cG.script = cG.REPO.script.def = result;
                    report(cG.script);
                    $(".venue").stageInjection();
                    Virtual = cG.comix.internals;
                    render();
                };
                reader.readAsText(this.files[0]);
            });
            movingtoolbar=false;
            $(document.body).mousemove(function() {
                if(!movingtoolbar) return 0;
                event.preventDefault();
                $("#nav-toolbar").offset({top: event.pageY-10,left: event.pageX-10});
            });
            $("#nav-move").click(function() {
                //console.log("nav-move");
                if(movingtoolbar) movingtoolbar=false;
                else movingtoolbar=true;
                //event.preventDefault();
            });
            $("#_set").click(function() {
                $("#settings_contain").slideToggle();
            });
            $("#_des").click(function() {
                $("#design_contain").slideToggle();
            });
            $("#ExBtn").click(function(){return expfunct()});
            $("#ExBtnCL").click(function(){return expfunct()});
            expfunct = function() {
                /*delete window.alert;
                    alert("Settings Configured!");*/
                var inclusion = ["parent","offset","config", "pyr", "loading", "pages", "chapters", "dir", "startpage", "pagestartnum", "readdir" , "additive", "chapterstartnum", "imgprebuffer", "imgpostbuffer", "back", "appendmismatch", "appendorder", "appendorderdir", "alt", "hover", "title","perm","anim8","special", "url", "release", "note", "absolute", "description", "start", "end", "title", "thumb", "diameter","lines","rate","xpos","ypos","back","color"];
                Virtual.config.dir = $("#dir").val();
                    Virtual.config.pagestartnum = document.getElementById("psn_1").checked;
                    Virtual.config.readdir = document.getElementById("rdr_1").checked;
                    Virtual.config.additive = $("#add_").val();//document.getElementById("add_1").checked;
                    Virtual.config.chapterstartnum = document.getElementById("csn_1").checked;
                Virtual.config.startpage = parseInt($("#strp").val(),10);/*document.getElementById("strp_1").checked;*/
                Virtual.config.imgprebuffer = parseInt($("#prb").val(),10);
                Virtual.config.imgpostbuffer = parseInt($("#ptb").val(),10);
                Virtual.config.back = $.data($("#ptb"),"color");
                Virtual.pyr.appendmismatch = document.getElementById("pyr_0").checked;
                if (document.getElementById("spyr_0").checked) {
                    Virtual.pyr.appendorder = 0;
                } else if (document.getElementById("spyr_1").checked) {
                    Virtual.pyr.appendorder = 1;
                } else if (document.getElementById("spyr_2").checked) {
                    Virtual.pyr.appendorder = 2;
                } else if (document.getElementById("spyr_3").checked) {
                    Virtual.pyr.appendorder = 3;
                }
                Virtual.pyr.appendorderdir = document.getElementById("spyro_0").checked;
                Virtual.loading = spin;
                
                $('.setlink').remove();
                var refh = "<a onClick=$('.setlink').remove() class='setlink' href='data: text/json;charset=utf-8," + JSON.stringify(Virtual, inclusion) + "' download='config.json' autofocus>config.json<br></a>",
                    formref = "<a onClick=$('.setlink').remove() class='setlink' href='data: text/json;charset=utf-8," + JSON.stringify(Virtual,inclusion,4) + "' download='config.json' autofocus>config.json<br></a>";
                console.log(formref);
                $(refh).appendTo("#MHEAD");
                $(refh).appendTo("#MHEADCL");
            };
            /*$("#InBtn").click(function() {
                $('#indlink').remove();
                var refh = "";
                console.log(refh);
                $(refh).appendTo("#MHEAD");
            });
            $("#DsBtn").click(function() {
                $('#deslink').remove(); temporary, using predefined scene
                var refh = "OUTDATED";
                console.log(refh);
                $(refh).appendTo("#MHEAD");
            });*/
            confaction = function(op) {
                if(!editfile.type&&op>=0){
                    if(op){
                        Virtual.pages[editfile.id[0]].title=$("#TEMP_title").val();
                        Virtual.pages[editfile.id[0]].hover=$("#TEMP_hover").val();
                        Virtual.pages[editfile.id[0]].note=$("#TEMP_note").val();
                        Virtual.pages[editfile.id[0]].alt=$("#TEMP_alt").val();
                        Virtual.pages[editfile.id[0]].release=$("#TEMP_release").val();
                        Virtual.pages[editfile.id[0]].url=[$("#TEMP_url").val()];
                        Virtual.pages[editfile.id[0]].perm=document.getElementById("TEMP_perm").checked;
                        Virtual.pages[editfile.id[0]].anim8=document.getElementById("TEMP_anim8").checked;
                        Virtual.pages[editfile.id[0]].special=$("#TEMP_special").val();
                        Virtual.pages[editfile.id[0]].absolute=document.getElementById("TEMP_abs").checked;
                        switch(editfile.id[0]) {
                            case 0:
                                Virtual.pages[editfile.id[0]].desig=-1
                                break;
                            case Virtual.pages.length-1:
                                Virtual.pages[editfile.id[0]].desig=1;
                                break;
                            default:
                                Virtual.pages[editfile.id[0]].desig=0;
                        }
                        Virtual.pages[editfile.id[0]].loaded = false;
                    }
                    else
                        Virtual.pages.splice(editfile.id[0], 1);
                }
                else if (op>=0){
                    if(op){
                        Virtual.chapters[editfile.id[0]].title=$("#TEMP_title").val();
                        Virtual.chapters[editfile.id[0]].thumb=$("#TEMP_thumb").val();
                        Virtual.chapters[editfile.id[0]].description=$("#TEMP_description").val();
                        Virtual.chapters[editfile.id[0]].start=$("#TEMP_start").val();
                        Virtual.chapters[editfile.id[0]].end=$("#TEMP_end").val();
                        Virtual.chapters[editfile.id[0]].parent=$("#TEMP_par").val();
                    }
                    else
                        Virtual.pages.splice(editfile.id[0], 1);
                }
                $('#edit').empty();
                editfile.id=[-1];
                editfile.dirty=false;
                editfile.type=0;
                editfile.multi=false;
                //if (op>=0)
                render();
            }
            settings = function(ele) {
                var key = ele.id;
                var lee = key.substring(1);
                var res = '';
                var p;
                var base;
                var end = "<button id='sveset' onclick='confaction(1)'>Save</button>&nbsp;<button id='canset' onclick='confaction(-1)'>Cancel</button>&nbsp;<button id='delset' style='color:red;' onclick='confaction(0)'>Delete</button>";
                if(key[0]=='s'){
                    p = Virtual.pages;
                    editfile.type = 0;
                    base = "<form id='TEMPFORM' autofocus><label for='TEMP_title'>Title&nbsp</label><input value='" + p[lee].title + "' id='TEMP_title' type='text' autofocus><br><label for='TEMP_hover'>Hover&nbsp</label><input value='" + p[lee].hover + "' id='TEMP_hover' type='text' title='Text on Mouse Over'><br><label for='TEMP_note'>Image Info&nbsp</label><input value='" + p[lee].note + "' id='TEMP_note' type='text'><br><label for='TEMP_alt'>Alt Text&nbsp</label><input value='" + p[lee].alt + "' id='TEMP_alt' type='text' title='If the image fails to load this text is loaded instead'><br><label for='TEMP_release'>Release Date&nbsp </label><input value='" + p[lee].release + "' id='TEMP_release' type='number' title='When should this slide be avaliable'><br><label for='TEMP_url'>URL&nbsp</label><input value='" + p[lee].url + "' id='TEMP_url' type='text' title='Filename of the image'><br><label for='TEMP_perm'>Permanent&nbsp</label><input " + p[lee].perm + " id='TEMP_perm' type='checkbox' title='Whether the image should always be loaded'><br><label for='TEMP_anim8'>Animate&nbsp</label><input " + p[lee].anim8 + " id='TEMP_anim8' type='checkbox' title='Whether the image/slide is animated'><br><label for='TEMP_abs'>Absolute&nbsp</label><input " + p[lee].absolute + " id='TEMP_abs' type='checkbox' title='The path is absolute(ignores asset path)'><br><label for='TEMP_special'>Special Code:&nbsp</label><textarea rows='4' cols='50' id='TEMP_perm'title='If the slide is not a static image, video/object/embed, put the code to render it here'></textarea><br></form>";
                }
                else{
                    p = Virtual.chapters;
                    editfile.type = 1;
                    base = "<form id='TEMPFORM' autofocus><label for='TEMP_title'>Title&nbsp</label><input value='" + p[lee].title + "' id='TEMP_title' type='text' autofocus><br><label for='TEMP_thumb'>Thumbnail&nbsp</label><input value='" + p[lee].thumb + "' id='TEMP_thumb' type='text'><br><label for='TEMP_description'>Description&nbsp</label><input value='" + p[lee].description + "' id='TEMP_description' type='text' title='Chapter description'><br><label for='TEMP_start'>Start&nbsp</label><input value='" + p[lee].start + "' id='TEMP_start' type='number' min='-1' title='Starting page ID value, use -1 if the chapter contains no starting page'>&nbsp;&nbsp;<label for='TEMP_end'>End&nbsp</label><input value='" + p[lee].end + "' id='TEMP_end' type='number' min='-1' title='Ending page ID value, use -1 if the chapter contains no ending page'><br><label for='TEMP_par'>Parent ID&nbsp</label><input value='" + p[lee].parent + "' id='TEMP_par' type= 'number' min='-1' title='Parent Chapter ID, use -1 if the chapter has no parent'><br></form>";
                } 
                if(!editfile.dirty && !editfile.multi){
                    $('#'+key).addClass('modify');
                    editfile.id[0]=parseInt(lee);
                    $('#edit').empty();
                    $('#edit').append(base+end);
                    $('#edit').focus();
                    render();
                } else if(editfile.dirty && !editfile.multi){
                    if (!confirm("You have unsaved settings, Overwrite?")) {
                        editfile.dirty = false;
                        $('#edit').empty();
                        $('#edit').append(base+end);
                        $('#edit').focus();
                    }
                }
            }
            report = function(conf) {
                //console.log(conf);
                document.getElementById("psn_0").checked = false;
                document.getElementById("psn_1").checked = false;
                document.getElementById("rdr_0").checked = false;
                document.getElementById("rdr_1").checked = false;
                //document.getElementById("add_0").checked = false;
                //document.getElementById("add_1").checked = false;
                document.getElementById("csn_0").checked = false;
                document.getElementById("csn_1").checked = false;
                /*document.getElementById("strp_0").checked = false;
            document.getElementById("strp_1").checked = false;*/
                document.getElementById("pyr_0").checked = false;
                document.getElementById("pyr_1").checked = false;
                document.getElementById("spyr_0").checked = false;
                document.getElementById("spyr_1").checked = false;
                document.getElementById("spyr_2").checked = false;
                document.getElementById("spyr_3").checked = false;  
                document.getElementById("spyro_0").checked = false;
                document.getElementById("spyro_1").checked = false;

                if (typeof conf.config === 'undefined') { //config module dependency
                    //default settings
                    $("#dir").val("assets/");
                    $("#add_").val("");
                    $("#prb").val("5");
                    $("#strp").val("0");
                    $.data($("#back_color"),"color","#fff"); 
                    document.getElementById("rdr_1").checked = true; 
                    //document.getElementById("add_1").checked = true; 
                    document.getElementById("psn_1").checked = true;
                    document.getElementById("csn_1").checked = true;
                } else {
                    $("#dir").val(conf.config.dir);
                    $("#prb").val(conf.config.imgprebuffer);
                    $("#ptb").val(conf.config.imgpostbuffer);
                    if (typeof conf.config.startpage === 'undefined') {
                        $("#strp").val("0");
                    } else if (conf.config.startpage) {
                        $("#strp").val(conf.config.startpage);
                    }
                    if (typeof conf.config.additive === void 0) {
                        $("#add_").val("0");
                    } else if (conf.config.additive) {
                        $("#add_").val(conf.config.additive);
                    }
                    if (typeof conf.config.back === 'undefined') {
                        $.data($("#back_color"),"color","#fff"); 
                    } else if (conf.config.back) {
                        $.data($("#back_color"),"color","#fff");
                        $("#back_color").spectrum.color = conf.config.back;//I DONT EVEN KNOW IF THIS WILL WORK, BUT FCK IT
                    }
                    if (conf.config.pagestartnum) document.getElementById("psn_1").checked = true;
                    else document.getElementById("psn_0").checked = true;
                    if (conf.config.readdir) document.getElementById("rdr_1").checked = true;
                    else document.getElementById("rdr_0").checked = true;
                    //if (conf.config.additive) document.getElementById("add_1").checked = true;
                    //else document.getElementById("add_0").checked = true;
                    if (conf.config.chapterstartnum) document.getElementById("csn_1").checked = true;
                    else document.getElementById("csn_0").checked = true;
                }
                if (typeof conf.pyr === 'undefined') { //pyr module dependency
                    //default settings
                    document.getElementById("pyr_0").checked = true;
                    document.getElementById("spyr_0").checked = true;
                    document.getElementById("spyro_0").checked = true;
                } else {
                    if (conf.pyr.appendmismatch) {
                        document.getElementById("pyr_0").checked = true;
                    } else {
                        document.getElementById("pyr_1").checked = true;
                    }
                    if (!conf.pyr.appendorder) {
                        document.getElementById("spyr_0").checked = true;
                    } else if (conf.pyr.appendorder == 1) {
                        document.getElementById("spyr_1").checked = true;
                    } else if (conf.pyr.appendorder == 2) {
                        document.getElementById("spyr_2").checked = true;
                    } else if (conf.pyr.appendorder == 3) {
                        document.getElementById("spyr_3").checked = true;
                    }
                    if (conf.pyr.appendorderdir) {
                        document.getElementById("spyro_0").checked = true;
                    } else {
                        document.getElementById("spyro_1").checked = true;
                    }
                }
                if (typeof conf.loading === 'undefined') { /*loading module dependency*/
                    /*default settings*/
                    $("#lin").val(16);
                    $("#rat").val(33.333333333333336);
                    $("#dia").val(250);
                    $("#xpose").val(0.5);
                    $("#ypose").val(0.5);
                    $("#back_load").spectrum.color="#fff";
                    $("#color_load").spectrum.color="#373737";
                } else {
                    $("#lin").val(conf.loading.lines);
                    $("#rat").val(conf.loading.rate);
                    $("#dia").val(conf.loading.diameter);
                    $("#xpose").val(conf.loading.xpos);
                    $("#ypose").val(conf.loading.ypos);
                    $("#back_load").spectrum.color=conf.loading.back;
                    $("#color_load").spectrum.color=conf.loading.color;
                }
            }
        }
        dfr=function(){
            /*!
     * Implementation of the Shunting yard algorithm
     * look it up: http://en.wikipedia.org/wiki/Shunting-yard_algorithm
     *
     * Copyright 2013, Georg Tavonius
     * Licensed under the MIT license.
     *
     * @version 1.0.1
     *
     * @author Georg Tavonius a.k.a. Calamari (http://github.com/Calamari)
     * @homepage http://github.com/Calamari/shunting-yard.js
     */!function(e){"use strict";function t(e,t,n,r,i){return n=n||"left",{name:e,precedence:t,params:r,method:i,greaterThen:function(e){return t>e.precedence},greaterThenEqual:function(e){return t>=e.precedence},equalThen:function(e){return t===e.precedence},lessThen:function(e){return t<e.precedence},lessThenEqual:function(e){return t<=e.precedence},leftAssoc:function(){return"left"===n},rightAssoc:function(){return"right"===n}}}function n(e,t,n){return{name:e,params:t,method:n}}var r=window.jaz||{};r.shuntingYard=function(t){function n(e){return"("===e}function i(e){return")"===e}function s(e){return r.Operators[e]}function c(e){return r.Functions[e]}var o,a,d,l,u,f,h,p=[],v=[];for(d=0,l=t.length;l>d;++d)if(u=t[d]," "!==u){if(a&&(u=a+=u,a=null),n(u))v.push(u);else if(c(u))v.push(u);else if(i(u)){for(;(f=v.pop())&&!n(f);)c(f)||p.push(f);if(f===e)return null}else if(s(u)){if(!o||"("===o){a=u;continue}for(;v.length&&(h=r.Operators[u],f=r.Operators[v[v.length-1]],f&&h)&&(h.leftAssoc()&&h.lessThenEqual(f)||h.lessThen(f));)p.push(v.pop());v.push(u)}else!o||n(o)||s(o)?p.push(u):p[p.length-1]+=u;o=u}for(;v.length;){if(u=v.pop(),n(u))return null;p.push(u)}return p},r.Operator=t,r.Operators={"+":new t("+",2,"left",2,function(e,t){return e+t}),"-":new t("-",2,"left",2,function(e,t){return e-t}),"*":new t("*",3,"left",2,function(e,t){return e*t}),"/":new t("/",3,"left",2,function(e,t){return e/t}),"^":new t("^",4,"right",2,function(e,t){return Math.pow(e,t)})},r.Function=n,r.Functions={},window.jaz=r}(),/*!
     * Resolves a RPN
     *
     * Copyright 2013, Georg Tavonius
     * Licensed under the MIT license.
     *
     * @author Georg Tavonius a.k.a. Calamari (http://github.com/Calamari)
     * @homepage http://github.com/Calamari/shunting-yard.js
     */!function(){"use strict";var e=window.jaz||{};e.resolveRPN=function(t){function n(t){return e.Operators[t]||e.Functions[t]}var r,i,s,c=[];for(r=0,i=t.length;i>r;++r)s=n(t[r]),c.push(s?s.method.apply(this,c.splice(-s.params)):parseFloat(t[r]));return c[0]},window.jaz=e}();jqdep();/*! humane.js: wavded.github.com/humane-js/ (MIT) (c) Marc Harter (@wavded)*/!function(e,t,n){"undefined"!=typeof module?module.exports=n(e,t):"function"==typeof define&&"object"==typeof define.amd?define(n):t[e]=n(e,t)}("humane",this,function(){var e=window,t=document,n={on:function(t,n,r){"addEventListener"in e?t.addEventListener(n,r,!1):t.attachEvent("on"+n,r)},off:function(t,n,r){"removeEventListener"in e?t.removeEventListener(n,r,!1):t.detachEvent("on"+n,r)},bind:function(e,t){return function(){e.apply(t,arguments)}},isArray:Array.isArray||function(e){return"[object Array]"===Object.prototype.toString.call(e)},config:function(e,t){return null!=e?e:t},transSupport:!1,useFilter:/msie [678]/i.test(navigator.userAgent),_checkTransition:function(){var e=t.createElement("div"),n={webkit:"webkit",Moz:"",O:"o",ms:"MS"};for(var r in n)r+"Transition"in e.style&&(this.vendorPrefix=n[r],this.transSupport=!0)}};n._checkTransition();var r=function(t){t||(t={}),this.queue=[],this.baseCls=t.baseCls||"humane",this.addnCls=t.addnCls||"",this.timeout="timeout"in t?t.timeout:2500,this.waitForMove=t.waitForMove||!1,this.clickToClose=t.clickToClose||!1,this.timeoutAfterMove=t.timeoutAfterMove||!1,this.container=t.container;try{this._setupEl()}catch(r){n.on(e,"load",n.bind(this._setupEl,this))}};return r.prototype={constructor:r,_setupEl:function(){var e=t.createElement("div");if(e.style.display="none",!this.container){if(!t.body)throw"document.body is null";this.container=t.body}this.container.appendChild(e),this.el=e,this.removeEvent=n.bind(function(){var e=n.config(this.currentMsg.timeoutAfterMove,this.timeoutAfterMove);e?setTimeout(n.bind(this.remove,this),e):this.remove()},this),this.transEvent=n.bind(this._afterAnimation,this),this._run()},_afterTimeout:function(){n.config(this.currentMsg.waitForMove,this.waitForMove)?this.removeEventsSet||(n.on(t.body,"mousemove",this.removeEvent),n.on(t.body,"click",this.removeEvent),n.on(t.body,"keypress",this.removeEvent),n.on(t.body,"touchstart",this.removeEvent),this.removeEventsSet=!0):this.remove()},_run:function(){if(!this._animating&&this.queue.length&&this.el){this._animating=!0,this.currentTimer&&(clearTimeout(this.currentTimer),this.currentTimer=null);var e=this.queue.shift(),t=n.config(e.clickToClose,this.clickToClose);t&&(n.on(this.el,"click",this.removeEvent),n.on(this.el,"touchstart",this.removeEvent));var r=n.config(e.timeout,this.timeout);r>0&&(this.currentTimer=setTimeout(n.bind(this._afterTimeout,this),r)),n.isArray(e.html)&&(e.html="<ul><li>"+e.html.join("<li>")+"</ul>"),this.el.innerHTML=e.html,this.currentMsg=e,this.el.className=this.baseCls,n.transSupport?(this.el.style.display="block",setTimeout(n.bind(this._showMsg,this),50)):this._showMsg()}},_setOpacity:function(e){if(n.useFilter)try{this.el.filters.item("DXImageTransform.Microsoft.Alpha").Opacity=100*e}catch(t){}else this.el.style.opacity=e+""},_showMsg:function(){var e=n.config(this.currentMsg.addnCls,this.addnCls);if(n.transSupport)this.el.className=this.baseCls+" "+e+" "+this.baseCls+"-animate";else{var t=0;this.el.className=this.baseCls+" "+e+" "+this.baseCls+"-js-animate",this._setOpacity(0),this.el.style.display="block";var r=this,i=setInterval(function(){1>t?(t+=.1,t>1&&(t=1),r._setOpacity(t)):clearInterval(i)},30)}},_hideMsg:function(){var e=n.config(this.currentMsg.addnCls,this.addnCls);if(n.transSupport)this.el.className=this.baseCls+" "+e,n.on(this.el,n.vendorPrefix?n.vendorPrefix+"TransitionEnd":"transitionend",this.transEvent);else var t=1,r=this,i=setInterval(function(){t>0?(t-=.1,0>t&&(t=0),r._setOpacity(t)):(r.el.className=r.baseCls+" "+e,clearInterval(i),r._afterAnimation())},30)},_afterAnimation:function(){n.transSupport&&n.off(this.el,n.vendorPrefix?n.vendorPrefix+"TransitionEnd":"transitionend",this.transEvent),this.currentMsg.cb&&this.currentMsg.cb(),this.el.style.display="none",this._animating=!1,this._run()},remove:function(e){var r="function"==typeof e?e:null;n.off(t.body,"mousemove",this.removeEvent),n.off(t.body,"click",this.removeEvent),n.off(t.body,"keypress",this.removeEvent),n.off(t.body,"touchstart",this.removeEvent),n.off(this.el,"click",this.removeEvent),n.off(this.el,"touchstart",this.removeEvent),this.removeEventsSet=!1,r&&this.currentMsg&&(this.currentMsg.cb=r),this._animating?this._hideMsg():r&&r()},log:function(e,t,n,r){var i={};if(r)for(var s in r)i[s]=r[s];if("function"==typeof t)n=t;else if(t)for(var s in t)i[s]=t[s];return i.html=e,n&&(i.cb=n),this.queue.push(i),this._run(),this},spawn:function(e){var t=this;return function(n,r,i){return t.log.call(t,n,r,i,e),t}},create:function(e){return new r(e)}},new r})},
        jqdep=function(){if(void 0===window.jQuery)return setTimeout(jqdep,300);var e;/*! jquery-spoiler v1.3.0: (MIT) (c)2014 Triangle717 (http://le717.github.io) and Jarred Ballard (http://jarred.io/)*/!function(e){"use strict";"function"==typeof define&&define.amd?define(["jquery"],e):"object"==typeof exports?module.exports=e:e(jQuery)}(function(e){"use strict";e.fn.spoiler=function(t){var n=e.extend({contentClass:"spoiler-content",paddingValue:6,triggerEvents:!1,includePadding:!0,buttonActiveClass:"spoiler-active",spoilerVisibleClass:"spoiler-content-visible"},t),r="."+n.contentClass,i={};return e(r).each(function(){var t=e(this);t.css("overflow","hidden");var r=t.prop("scrollHeight");r=n.includePadding?r+parseInt(n.paddingValue,10):r;var s=t.attr("data-spoiler-link");i[s]=r+"px",t.css("height","0")}),e(this).on("click",function(){var t=e(this),s=t.attr("data-spoiler-link"),c=e(r+"[data-spoiler-link="+s+"]"),o={height:i[s]},a={height:"0"},d=c.hasClass(n.spoilerVisibleClass);c.css(d?a:o),n.triggerEvents&&t.trigger(d?"jq-spoiler-hidden":"jq-spoiler-visible"),c.toggleClass(n.spoilerVisibleClass),t.toggleClass(n.buttonActiveClass)}),this}});setup();workhorse()};

    !function() {
        return defer ? void(window.addEventListener ? window.addEventListener("load", dfr, !1) : window.attachEvent ? window.attachEvent("onload", dfr) : window.onload = dfr) : dfr()
    }();
</script>
            <?php submit_button(); ?>
        </form>
    </div>
    <h3 class="button" role="button">* Design</h3>
    <div id="design_contain">
        <!-- style="display: none;">-->
        <p>
            <!--<button id="InBtn" title="Create site template; this does not save settings it simply creates an index.html file">Site Template</button>&nbsp;
            <button id="DsBtn" title="Save Stage Design">Save Design</button>-->
        </p>
        <div id class="venue"></div>
    </div>
</div>
</div>
<?php }