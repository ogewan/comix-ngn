<?php 
function writer_settings(){?>
<div class="wrap">
<h2>Comix-ngn</h2>

<form method="post" action="options.php">
    <?php settings_fields( 'writer-group' ); ?>
    <?php do_settings_sections( 'writer-group' ); ?>
    <table class="form-table">
        <tr valign="top">
        <!--<th scope="row">Data</th>-->
        <td><input style="display:none" type="text" name="data_<?php $screen = get_current_screen();$pID =substr(strrchr($screen->id,"_"),1);echo $pID;?>" value="<?php echo esc_attr( get_option('data') ); ?>" /></td>
        </tr>
    </table>
    
    <?php submit_button(); ?>

</form>
</div>
<?php }