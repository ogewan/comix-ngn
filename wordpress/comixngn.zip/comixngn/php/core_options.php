<?php
function copt() {
    echo plugins_url( '/assets/static-c-comixngn_16.ico', __FILE__ );
    add_menu_page('CNGN Options', 'Comix-ngn', 'manage_options', 'cngn_slug', null, plugins_url( '/assets/static-c-comixngn_16.ico', __FILE__ ));
    add_submenu_page( 'cngn_slug', 'Page title', 'Sub-menu title', 'manage_options', 'my-submenu-handle', 'my_magic_function');
}
add_action( 'admin_menu', 'copt' );